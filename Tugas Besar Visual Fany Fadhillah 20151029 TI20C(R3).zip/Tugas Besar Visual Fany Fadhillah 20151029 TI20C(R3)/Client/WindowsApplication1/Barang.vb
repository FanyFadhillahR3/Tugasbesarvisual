﻿Public Class Barang
    Public Property kode_barang As String
    Public Property nama As String
    Public Property berat_barang As String

End Class
