﻿Public Class Transaksi
    Public Property kode_transaksi As String
    Public Property kode_barang As String
    Public Property kode_customer As String
    Public Property harga As String

End Class
