﻿Public Class Customer
    Public Property kode_customer As String
    Public Property nama_customer As String
    Public Property alamat As String
    Public Property email As String
End Class
